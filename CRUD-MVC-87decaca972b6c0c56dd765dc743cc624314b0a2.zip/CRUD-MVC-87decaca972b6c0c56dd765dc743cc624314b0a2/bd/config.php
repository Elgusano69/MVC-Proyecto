<?php 

define('DB_SERVER', 'localhost');
define('DB_NAME', 'crud_mvc');
define('DB_USER', 'root');
define('DB_PASS', '');

 ?>