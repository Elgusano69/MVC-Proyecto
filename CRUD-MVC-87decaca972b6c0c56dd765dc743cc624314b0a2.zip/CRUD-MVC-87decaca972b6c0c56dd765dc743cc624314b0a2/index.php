<?php

	require 'controller/controlador.php';

?>